/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useMemo } from 'react';
import { 
  onAuthStateChanged, 
  signInWithPopup, 
  GoogleAuthProvider, 
  signOut, 
  User,
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword
} from 'firebase/auth';
import { 
  collection, 
  query, 
  onSnapshot, 
  addDoc, 
  updateDoc, 
  deleteDoc, 
  doc, 
  orderBy,
  where,
  setDoc,
  getDoc,
  getDocFromServer
} from 'firebase/firestore';
import { auth, db } from './lib/firebase';
import { Book, UserProfile } from './types';
import { SUBJECTS_LIST, GRADE_LEVELS, DISTRICTS, BOOK_TYPES, GRADE_LEVEL_MAPPING, DISTRICT_MAPPING, SUBJECT_MAPPING, MUNICIPALITIES, ACQUISITION_MODES, SCHOOL_MAPPING, UTILIZATION_MODES, IMPACT_OPTIONS } from './constants';
import { 
  Search, 
  Plus, 
  LogOut, 
  FileDown, 
  FileUp, 
  Filter, 
  BookOpen, 
  ChevronDown, 
  Edit2,
  Download,
  BarChart3,
  Printer,
  X,
  Trash2,
  Users as UsersIcon
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import Papa from 'papaparse';
import { format, isWithinInterval, parseISO, startOfMonth, endOfMonth, startOfQuarter, endOfQuarter } from 'date-fns';

enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId: string | undefined;
    email: string | null | undefined;
    emailVerified: boolean | undefined;
    isAnonymous: boolean | undefined;
    tenantId: string | null | undefined;
    providerInfo: {
      providerId: string;
      displayName: string | null;
      email: string | null;
      photoUrl: string | null;
    }[];
  }
}

function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null) {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth.currentUser?.uid,
      email: auth.currentUser?.email,
      emailVerified: auth.currentUser?.emailVerified,
      isAnonymous: auth.currentUser?.isAnonymous,
      tenantId: auth.currentUser?.tenantId,
      providerInfo: auth.currentUser?.providerData.map(provider => ({
        providerId: provider.providerId,
        displayName: provider.displayName,
        email: provider.email,
        photoUrl: provider.photoURL
      })) || []
    },
    operationType,
    path
  }
  console.error('Firestore Error: ', JSON.stringify(errInfo));
  // We don't throw here to avoid crashing the whole app, but we log it clearly
}

const ADMIN_EMAIL = "carmonaloren042@gmail.com";

export default function App() {
  const [user, setUser] = useState<User | null>(null);
  const [userProfile, setUserProfile] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState(true);
  const [books, setBooks] = useState<Book[]>([]);
  const [allUsers, setAllUsers] = useState<UserProfile[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingBook, setEditingBook] = useState<Book | null>(null);
  const [showReports, setShowReports] = useState(false);
  const [showUsers, setShowUsers] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [expandedLevel, setExpandedLevel] = useState<string | null>(null);
  const [expandedDistrict, setExpandedDistrict] = useState<string | null>(null);
  const [expandedMunicipality, setExpandedMunicipality] = useState<string | null>(null);
  const [navDistrict, setNavDistrict] = useState('');
  const [navMunicipality, setNavMunicipality] = useState('');

  // Auth Listener
  useEffect(() => {
    // Test Firestore Connection
    const testConnection = async () => {
      try {
        await getDocFromServer(doc(db, '_connection_test_', 'ping'));
      } catch (error: any) {
        if (error.code === 'unavailable') {
          console.error("Firestore is unreachable.");
        }
      }
    };
    testConnection();

    let profUnsubscribe: (() => void) | null = null;

    const unsubscribe = onAuthStateChanged(auth, async (firebaseUser) => {
      if (firebaseUser) {
        setUser(firebaseUser);
        // Real-time listener for current user's profile
        if (profUnsubscribe) profUnsubscribe();
        profUnsubscribe = onSnapshot(doc(db, 'users', firebaseUser.uid), (snapshot) => {
          if (snapshot.exists()) {
            setUserProfile(snapshot.data() as UserProfile);
          } else if (firebaseUser.email === ADMIN_EMAIL) {
            // Auto-login for admin with virtual profile
            setUserProfile({
              uid: firebaseUser.uid,
              email: firebaseUser.email,
              firstName: 'System',
              surname: 'Admin',
              district: 'Admin',
              municipality: 'Admin',
              schoolName: 'Central Admin',
              role: 'admin',
              createdAt: new Date().toISOString()
            });
          } else {
            setUserProfile(null);
          }
          setLoading(false);
        }, (error) => {
          console.error("Profile listener error:", error);
          setLoading(false);
        });
      } else {
        setUser(null);
        setUserProfile(null);
        setLoading(false);
        if (profUnsubscribe) {
          profUnsubscribe();
          profUnsubscribe = null;
        }
      }
    });

    return () => {
      unsubscribe();
      if (profUnsubscribe) profUnsubscribe();
    };
  }, []);

  // Firestore Listener for Books (Global)
  useEffect(() => {
    if (!user) {
      setBooks([]);
      return;
    }

    const q = query(
      collection(db, 'books'),
      orderBy('title', 'asc')
    );

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const bookData = snapshot.docs.map(doc => {
        const data = doc.data();
        return {
          id: doc.id,
          ...data,
          subject: Array.isArray(data.subject) ? data.subject[0] || '' : (data.subject || '')
        };
      }) as Book[];
      setBooks(bookData);
    }, (error) => {
      handleFirestoreError(error, OperationType.GET, 'books');
    });

    return unsubscribe;
  }, [user]);

  // Firestore Listener for All Users
  useEffect(() => {
    if (!user) {
      setAllUsers([]);
      return;
    }

    const q = query(collection(db, 'users'));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const userData = snapshot.docs.map(doc => doc.data() as UserProfile);
      setAllUsers(userData);
    }, (error) => {
      handleFirestoreError(error, OperationType.GET, 'users');
    });

    return unsubscribe;
  }, [user]);

  const handleLogin = async () => {
    try {
      const provider = new GoogleAuthProvider();
      await signInWithPopup(auth, provider);
    } catch (error) {
      console.error("Login error:", error);
    }
  };

  const handleLogout = () => signOut(auth);

  const filteredBooks = useMemo(() => {
    return books.filter(book => 
      book.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      book.subject?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      book.district.toLowerCase().includes(searchTerm.toLowerCase()) ||
      book.schoolName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      book.type.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (book.grade && book.grade.toLowerCase().includes(searchTerm.toLowerCase())) ||
      book.gradeLevel.toLowerCase().includes(searchTerm.toLowerCase()) ||
      book.district.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (book.municipality && book.municipality.toLowerCase().includes(searchTerm.toLowerCase()))
    );
  }, [books, searchTerm]);

  const stats = useMemo(() => {
    const totalBooks = books.length;
    const activeDistricts = new Set(books.map(b => b.district)).size;
    const totalSchools = new Set(books.map(b => b.schoolName)).size;
    const totalUsers = allUsers.length;
    return { totalBooks, activeDistricts, totalSchools, totalUsers };
  }, [books, allUsers]);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-bg">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-accent"></div>
      </div>
    );
  }

  if (!user || (!userProfile && !loading)) {
    return <LoginView onLogin={handleLogin} allUsers={allUsers} user={user} onLogout={handleLogout} />;
  }

  return (
    <div className="flex min-h-screen bg-bg text-text-main font-sans overflow-hidden relative">
      {/* Mobile Menu Overlay */}
      <AnimatePresence>
        {isMobileMenuOpen && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setIsMobileMenuOpen(false)}
            className="fixed inset-0 bg-primary/60 backdrop-blur-sm z-40 lg:hidden"
          />
        )}
      </AnimatePresence>

      {/* Sidebar */}
      <aside className={clsx(
        "fixed inset-y-0 left-0 w-[240px] bg-primary text-white flex flex-col p-5 z-50 transition-transform duration-300 lg:relative lg:translate-x-0 shrink-0",
        isMobileMenuOpen ? "translate-x-0" : "-translate-x-full"
      )}>
        <div className="flex items-center gap-3 mb-8 border-b border-secondary pb-4">
          <img 
            src="https://www.image2url.com/r2/default/images/1776324501949-c6254464-7439-4777-ad8a-f41d1244dba7.jpg" 
            alt="Logo" 
            className="w-10 h-10 rounded-full object-cover bg-white"
            referrerPolicy="no-referrer"
            onError={(e) => {
              (e.target as HTMLImageElement).src = 'https://picsum.photos/seed/education/100/100';
            }}
          />
          <div className="font-bold text-sm leading-tight tracking-tight uppercase">
            Inventory of Learning Resource
          </div>
          <button onClick={() => setIsMobileMenuOpen(false)} className="lg:hidden p-1 hover:bg-secondary rounded ml-auto">
            <X className="w-5 h-5" />
          </button>
        </div>
        
        <div className="space-y-6 overflow-y-auto pr-2 flex-1">
          <div className="sidebar-group">
            <span className="text-[10px] uppercase tracking-widest text-slate-400 font-bold mb-3 block">Quick Filters</span>
            <div className="space-y-1">
              <SidebarItem 
                active={!showReports && !showUsers} 
                onClick={() => { setShowReports(false); setShowUsers(false); setIsMobileMenuOpen(false); }} 
                icon={<BookOpen className="w-4 h-4" />}
              >
                All Resources
              </SidebarItem>
              <SidebarItem 
                active={showReports} 
                onClick={() => { setShowReports(true); setShowUsers(false); setIsMobileMenuOpen(false); }} 
                icon={<BarChart3 className="w-4 h-4" />}
              >
                Reports
              </SidebarItem>
              <SidebarItem 
                active={showUsers} 
                onClick={() => { setShowUsers(true); setShowReports(false); setIsMobileMenuOpen(false); }} 
                icon={<UsersIcon className="w-4 h-4" />}
              >
                Users ({stats.totalUsers})
              </SidebarItem>
            </div>
          </div>

          <div className="sidebar-group">
            <span className="text-[10px] uppercase tracking-widest text-slate-400 font-bold mb-3 block">Grade Levels</span>
            <div className="space-y-1">
              {GRADE_LEVELS.map(level => (
                <div key={level} className="space-y-1">
                  <SidebarItem 
                    active={expandedLevel === level || searchTerm === level} 
                    onClick={() => {
                      setExpandedLevel(expandedLevel === level ? null : level);
                      setSearchTerm(level);
                    }}
                    icon={<ChevronDown className={clsx("w-4 h-4 transition-transform", expandedLevel === level && "rotate-180")} />}
                  >
                    {level}
                  </SidebarItem>
                  <AnimatePresence>
                    {expandedLevel === level && (
                      <motion.div 
                        initial={{ height: 0, opacity: 0 }}
                        animate={{ height: 'auto', opacity: 1 }}
                        exit={{ height: 0, opacity: 0 }}
                        className="overflow-hidden pl-6 space-y-1"
                      >
                        {GRADE_LEVEL_MAPPING[level]?.map(grade => (
                          <button 
                            key={grade}
                            onClick={() => {
                              setSearchTerm(grade);
                              setIsMobileMenuOpen(false);
                            }}
                            className={clsx(
                              "w-full text-left px-3 py-1.5 text-[11px] font-bold rounded-lg transition-all",
                              searchTerm === grade ? "text-white bg-secondary" : "text-slate-400 hover:text-white hover:bg-secondary/50"
                            )}
                          >
                            {grade}
                          </button>
                        ))}
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>
              ))}
            </div>
          </div>

          <div className="sidebar-group">
            <span className="text-[10px] uppercase tracking-widest text-slate-400 font-bold mb-3 block">Districts & Schools</span>
            <div className="space-y-1 text-slate-300">
              {DISTRICTS.map(district => (
                <div key={district} className="space-y-1">
                  <SidebarItem 
                    active={expandedDistrict === district || searchTerm === district} 
                    onClick={() => {
                      setExpandedDistrict(expandedDistrict === district ? null : district);
                      setSearchTerm(district);
                    }}
                    icon={<ChevronDown className={clsx("w-4 h-4 transition-transform", expandedDistrict === district && "rotate-180")} />}
                  >
                    {district}
                  </SidebarItem>
                  <AnimatePresence>
                    {expandedDistrict === district && (
                      <motion.div 
                        initial={{ height: 0, opacity: 0 }}
                        animate={{ height: 'auto', opacity: 1 }}
                        exit={{ height: 0, opacity: 0 }}
                        className="overflow-hidden pl-4 space-y-1"
                      >
                        {DISTRICT_MAPPING[district]?.map(municipality => (
                          <div key={municipality} className="space-y-1">
                            <button 
                              onClick={() => {
                                setExpandedMunicipality(expandedMunicipality === municipality ? null : municipality);
                                setSearchTerm(municipality);
                              }}
                              className={clsx(
                                "w-full text-left px-3 py-1.5 text-[11px] font-bold rounded-lg transition-all flex items-center justify-between group",
                                searchTerm === municipality || expandedMunicipality === municipality ? "text-white bg-secondary/80" : "text-slate-400 hover:text-white hover:bg-secondary/50"
                              )}
                            >
                              <span className="truncate">{municipality}</span>
                              {SCHOOL_MAPPING[municipality] && (
                                <ChevronDown className={clsx("w-3 h-3 transition-transform", expandedMunicipality === municipality && "rotate-180")} />
                              )}
                            </button>
                            
                            <AnimatePresence>
                              {expandedMunicipality === municipality && SCHOOL_MAPPING[municipality] && (
                                <motion.div 
                                  initial={{ height: 0, opacity: 0 }}
                                  animate={{ height: 'auto', opacity: 1 }}
                                  exit={{ height: 0, opacity: 0 }}
                                  className="overflow-hidden pl-4 space-y-1 border-l border-slate-700 ml-2"
                                >
                                  {SCHOOL_MAPPING[municipality].map(school => (
                                    <button 
                                      key={school}
                                      onClick={() => {
                                        setSearchTerm(school);
                                        setIsMobileMenuOpen(false);
                                      }}
                                      className={clsx(
                                        "w-full text-left px-3 py-1.5 text-[11px] font-semibold rounded-lg transition-all truncate",
                                        searchTerm === school ? "text-accent bg-accent/10" : "text-slate-300 hover:text-white"
                                      )}
                                      title={school}
                                    >
                                      {school}
                                    </button>
                                  ))}
                                </motion.div>
                              )}
                            </AnimatePresence>
                          </div>
                        ))}
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>
              ))}
            </div>
          </div>
        </div>

        <div className="mt-auto pt-6 border-t border-secondary">
          <div className="flex items-center gap-3 mb-4">
            {user.photoURL ? (
              <img src={user.photoURL} alt="" className="w-8 h-8 rounded-full border border-secondary object-cover" referrerPolicy="no-referrer" />
            ) : (
              <div className="w-8 h-8 rounded-full bg-secondary flex items-center justify-center font-bold text-xs">
                {userProfile?.firstName?.[0] || user.displayName?.[0] || 'U'}
              </div>
            )}
            <div className="flex-1 min-w-0">
              <p className="text-xs font-bold truncate">{userProfile ? `${userProfile.firstName} ${userProfile.surname}` : user.displayName}</p>
              <p className="text-[10px] text-slate-400 truncate">{user.email}</p>
            </div>
          </div>
          <button 
            onClick={handleLogout}
            className="w-full flex items-center justify-center gap-2 py-2 bg-secondary hover:bg-slate-700 rounded-lg text-xs font-bold transition-colors"
          >
            <LogOut className="w-3 h-3" />
            Logout
          </button>
        </div>
      </aside>

      {/* Main Container */}
      <div className="flex-1 flex flex-col overflow-hidden">
        <header className="flex flex-col sm:flex-row justify-between items-center gap-4 p-4 lg:p-6 bg-white border-b border-border shrink-0">
          <div className="flex items-center gap-3 w-full sm:w-auto">
            <button 
              onClick={() => setIsMobileMenuOpen(true)}
              className="lg:hidden p-2 hover:bg-slate-100 rounded-lg text-text-muted"
            >
              <Filter className="w-5 h-5" />
            </button>
            <div className="relative flex-1 sm:w-[200px] lg:w-[250px]">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-text-muted w-4 h-4" />
              <input 
                type="text" 
                placeholder="Search resources..."
                className="w-full pl-11 pr-4 py-2 bg-slate-50 border border-border rounded-lg text-sm focus:ring-2 focus:ring-accent outline-none transition-all"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>

            <div className="hidden lg:flex items-center gap-2 border-l border-slate-200 pl-4 ml-2">
              <select 
                className={clsx(
                  "px-3 py-1.5 bg-slate-50 border border-border rounded-lg text-[11px] font-bold uppercase tracking-wider outline-none focus:ring-1 focus:ring-accent min-w-[120px] text-slate-700 transition-opacity",
                  !navDistrict ? "opacity-20" : "opacity-100"
                )}
                value={navDistrict}
                onChange={(e) => {
                  const d = e.target.value;
                  setNavDistrict(d);
                  setNavMunicipality('');
                  setSearchTerm(d === '' || d === 'all' ? '' : d);
                }}
              >
                <option value="" disabled hidden>--click to select--</option>
                <option value="all">Select District</option>
                {DISTRICTS.map(d => <option key={d} value={d}>{d}</option>)}
              </select>

              {navDistrict !== '' && navDistrict !== 'all' && (
                <motion.select 
                  initial={{ opacity: 0, x: -10 }}
                  animate={{ opacity: 1, x: 0 }}
                  className={clsx(
                    "px-3 py-1.5 bg-slate-50 border border-border rounded-lg text-[11px] font-bold uppercase tracking-wider outline-none focus:ring-1 focus:ring-accent min-w-[120px] text-slate-700 transition-opacity",
                    !navMunicipality ? "opacity-20" : "opacity-100"
                  )}
                  value={navMunicipality}
                  onChange={(e) => {
                    const m = e.target.value;
                    setNavMunicipality(m);
                    setSearchTerm(m === '' || m === 'all' ? navDistrict : m);
                  }}
                >
                  <option value="" disabled hidden>--click to select--</option>
                  <option value="all">Municipalities</option>
                  {DISTRICT_MAPPING[navDistrict]?.map(m => <option key={m} value={m}>{m}</option>)}
                </motion.select>
              )}

              {navMunicipality !== '' && navMunicipality !== 'all' && SCHOOL_MAPPING[navMunicipality] && (
                <motion.select 
                  initial={{ opacity: 0, x: -10 }}
                  animate={{ opacity: 1, x: 0 }}
                  className="px-3 py-1.5 bg-slate-50 border border-border rounded-lg text-[11px] font-bold uppercase tracking-wider outline-none focus:ring-1 focus:ring-accent min-w-[120px] text-slate-700"
                  onChange={(e) => {
                    const s = e.target.value;
                    setSearchTerm(s === '' || s === 'all' ? navMunicipality : s);
                  }}
                >
                  <option value="" disabled hidden>--click to select--</option>
                  <option value="all">List of Schools</option>
                  {SCHOOL_MAPPING[navMunicipality]?.map(s => <option key={s} value={s}>{s}</option>)}
                </motion.select>
              )}
            </div>
          </div>
          <div className="flex items-center gap-2 w-full sm:w-auto justify-end">
            {!showReports && !showUsers && (
              <>
                <div className="hidden md:block">
                  <CSVTools books={books} userId={user.uid} userProfile={userProfile} />
                </div>
                <button 
                  onClick={() => {
                    setEditingBook(null);
                    setIsModalOpen(true);
                  }}
                  className="flex-1 sm:flex-none bg-accent hover:bg-blue-700 text-white px-4 py-2 rounded-lg font-bold text-xs sm:text-sm transition-colors shadow-sm flex items-center justify-center gap-2"
                >
                  <Plus className="w-4 h-4" />
                  Add New
                </button>
              </>
            )}
          </div>
        </header>

        <div className="flex-1 overflow-y-auto p-4 lg:p-6">
          {showReports ? (
            <ReportsView books={books} onClose={() => setShowReports(false)} />
          ) : showUsers ? (
            <UsersView users={allUsers} currentUserProfile={userProfile} onClose={() => setShowUsers(false)} />
          ) : (
            <div className="flex-1 flex flex-col">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-3 lg:gap-4 mb-6">
                <StatCard label="TOTAL BOOKS" value={stats.totalBooks.toLocaleString()} />
                <StatCard label="Total Districts" value={`${stats.activeDistricts}`} />
                <StatCard label="Total School" value={`${stats.totalSchools}`} />
                <StatCard label="Total Users" value={`${stats.totalUsers}`} />
              </div>

              <div className="bg-white border border-border rounded-xl shadow-sm overflow-hidden">
                <div className="overflow-x-auto">
                  <table className="w-full text-left border-collapse min-w-[900px]">
                    <thead>
                      <tr className="bg-slate-50 border-b-2 border-border">
                        <th className="px-4 py-3 text-[10px] font-bold text-secondary uppercase tracking-wider">Book Title</th>
                        <th className="px-4 py-3 text-[10px] font-bold text-secondary uppercase tracking-wider">Type</th>
                        <th className="px-4 py-3 text-[10px] font-bold text-secondary uppercase tracking-wider text-center">Grade</th>
                        <th className="px-4 py-3 text-[10px] font-bold text-secondary uppercase tracking-wider">Subject</th>
                        <th className="px-4 py-3 text-[10px] font-bold text-secondary uppercase tracking-wider">Name of School</th>
                        <th className="px-4 py-3 text-[10px] font-bold text-secondary uppercase tracking-wider">Location</th>
                        <th className="px-4 py-3 text-[10px] font-bold text-secondary uppercase tracking-wider text-center">Usable</th>
                        <th className="px-4 py-3 text-[10px] font-bold text-secondary uppercase tracking-wider text-center">P. Damaged</th>
                        <th className="px-4 py-3 text-[10px] font-bold text-secondary uppercase tracking-wider text-center">Damaged</th>
                        <th className="px-4 py-3 text-[10px] font-bold text-secondary uppercase tracking-wider text-center">Lost</th>
                        <th className="px-4 py-3 text-[10px] font-bold text-secondary uppercase tracking-wider text-center">Condemn.</th>
                        <th className="px-4 py-3 text-[10px] font-bold text-secondary uppercase tracking-wider text-right">Total Copies</th>
                        <th className="px-4 py-3 text-[10px] font-bold text-secondary uppercase tracking-wider text-center">User</th>
                        <th className="px-4 py-3 text-[10px] font-bold text-secondary uppercase tracking-wider text-center">MODE OF ACQUISITION</th>
                        <th className="px-4 py-3 text-[10px] font-bold text-secondary uppercase tracking-wider text-center">MODE OF UTILIZATION</th>
                        <th className="px-4 py-3 text-[10px] font-bold text-secondary uppercase tracking-wider text-center">IMPACT ON LEARNERS</th>
                        <th className="px-4 py-3 text-[10px] font-bold text-secondary uppercase tracking-wider text-center">Actions</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-border">
                      <AnimatePresence mode="popLayout">
                        {filteredBooks.map((book) => (
                          <motion.tr 
                            layout
                            initial={{ opacity: 0 }}
                            animate={{ opacity: 1 }}
                            exit={{ opacity: 0 }}
                            key={book.id} 
                            className="hover:bg-slate-50 transition-colors group"
                          >
                            <td className="px-4 py-3">
                              <span className="text-xs font-bold text-text-main">{book.title}</span>
                            </td>
                            <td className="px-4 py-3 text-xs font-medium text-text-main">{book.type}</td>
                            <td className="px-4 py-3">
                              <div className="flex flex-col gap-1 items-center">
                                <span className="badge badge-grade">{book.gradeLevel}</span>
                                {book.grade && <span className="text-[10px] font-bold text-text-main">{book.grade}</span>}
                              </div>
                            </td>
                            <td className="px-4 py-3">
                              <div className="flex flex-wrap gap-1">
                                <span className="badge badge-subject">{book.subject}</span>
                              </div>
                            </td>
                            <td className="px-4 py-3 text-xs font-bold text-text-main">{book.schoolName}</td>
                            <td className="px-4 py-3">
                              <div className="flex flex-col gap-0.5">
                                <span className="text-xs font-bold text-text-main">{book.district}</span>
                                <span className="text-[11px] font-semibold text-slate-600">{book.municipality}</span>
                              </div>
                            </td>
                            <td className="px-4 py-3 text-xs text-center font-bold text-blue-600">{book.usable?.toLocaleString() || 0}</td>
                            <td className="px-4 py-3 text-xs text-center font-bold text-orange-500">{book.partiallyDamaged?.toLocaleString() || 0}</td>
                            <td className="px-4 py-3 text-xs text-center font-bold text-red-500">{book.damaged?.toLocaleString() || 0}</td>
                            <td className="px-4 py-3 text-xs text-center font-bold text-text-main">{book.lost?.toLocaleString() || 0}</td>
                            <td className="px-4 py-3 text-xs text-center font-bold text-text-main">{book.condemnable?.toLocaleString() || 0}</td>
                            <td className="px-4 py-3 text-xs font-black text-right text-primary">{(book.total || (book as any).copies || 0).toLocaleString()}</td>
                            <td className="px-4 py-3 text-[10px] text-center text-text-main font-bold uppercase">{book.addedBy || 'System'}</td>
                            <td className="px-4 py-3 text-xs text-center text-text-main font-medium italic max-w-[150px] truncate" title={book.acquisitionMode}>{book.acquisitionMode || '---'}</td>
                            <td className="px-4 py-3 text-xs text-center text-text-main font-medium italic max-w-[150px] truncate" title={book.utilizationMode}>{book.utilizationMode || '---'}</td>
                            <td className="px-4 py-3 text-xs text-center text-text-main font-medium italic max-w-[150px] truncate" title={book.impactOnLearners}>{book.impactOnLearners || '---'}</td>
                            <td className="px-4 py-3">
                              <div className="flex items-center justify-center gap-1">
                                {(book.userId === user.uid || userProfile?.role === 'admin') && (
                                  <button 
                                    onClick={() => { setEditingBook(book); setIsModalOpen(true); }} 
                                    className="p-1.5 text-text-muted hover:text-accent transition-colors"
                                    title="Edit/Update"
                                  >
                                    <Edit2 className="w-4 h-4" />
                                  </button>
                                )}
                                {(book.userId === user.uid || userProfile?.role === 'admin') && (
                                  <button 
                                    onClick={async () => {
                                      try {
                                        await deleteDoc(doc(db, 'books', book.id));
                                      } catch (error) {
                                        handleFirestoreError(error, OperationType.WRITE, `books/${book.id}`);
                                      }
                                    }} 
                                    className="p-1.5 text-text-muted hover:text-red-500 transition-colors"
                                    title="Delete Resource"
                                  >
                                    <Trash2 className="w-4 h-4" />
                                  </button>
                                )}
                                <button 
                                  onClick={() => {
                                    const printWindow = window.open('', '_blank');
                                    if (printWindow) {
                                      printWindow.document.write(`
                                        <html>
                                          <head>
                                            <title>Print Resource - ${book.title}</title>
                                            <style>
                                              body { font-family: sans-serif; padding: 40px; line-height: 1.6; color: #333; }
                                              .header { border-bottom: 2px solid #1e293b; margin-bottom: 20px; padding-bottom: 10px; }
                                              h1 { margin: 0; color: #1e293b; font-size: 28px; text-transform: uppercase; font-weight: 800; }
                                              .details { margin-bottom: 30px; }
                                              .detail-item { margin-bottom: 8px; font-size: 14px; }
                                              .label { font-weight: bold; color: #475569; width: 120px; display: inline-block; }
                                              .value { color: #0f172a; font-weight: 500; }
                                              .divider { border-top: 1px solid #e2e8f0; margin: 20px 0; }
                                              .section-title { font-weight: 800; font-size: 12px; color: #64748b; text-transform: uppercase; letter-spacing: 0.1em; margin-bottom: 15px; }
                                              .counts-grid { display: grid; grid-template-cols: repeat(3, 1fr); gap: 15px; background: #f8fafc; padding: 20px; border-radius: 8px; }
                                              .count-item { text-align: center; }
                                              .count-label { font-size: 10px; font-weight: bold; color: #64748b; text-transform: uppercase; }
                                              .count-value { font-size: 20px; font-weight: 800; color: #1e293b; }
                                              .total-box { grid-column: span 3; border-top: 1px solid #e2e8f0; padding-top: 10px; margin-top: 5px; text-align: right; }
                                              .remarks-box { background: #fff; border: 1px solid #e2e8f0; padding: 15px; border-radius: 8px; font-style: italic; color: #334155; min-height: 60px; }
                                              .footer { margin-top: 50px; font-size: 10px; color: #94a3b8; border-top: 1px solid #e2e8f0; padding-top: 10px; text-align: center; }
                                            </style>
                                          </head>
                                          <body>
                                            <div class="header">
                                              <h1>${book.title}</h1>
                                            </div>
                                            
                                            <div class="details">
                                              <div class="detail-item"><span class="label">Author:</span> <span class="value">${book.author || 'N/A'}</span></div>
                                              <div class="detail-item"><span class="label">Book Type:</span> <span class="value">${book.type}</span></div>
                                              <div class="detail-item"><span class="label">Grade:</span> <span class="value">${book.gradeLevel} ${book.grade ? `(${book.grade})` : ''}</span></div>
                                              <div class="detail-item"><span class="label">Subject:</span> <span class="value">${book.subject}</span></div>
                                              <div class="detail-item"><span class="label">District:</span> <span class="value">${book.district} (${book.municipality})</span></div>
                                              <div class="detail-item"><span class="label">School:</span> <span class="value">${book.schoolName}</span></div>
                                            </div>

                                            <div class="divider"></div>

                                            <div class="section-title">INVENTORY STATUS</div>
                                            <div class="counts-grid">
                                              <div class="count-item"><div class="count-label">Usable</div><div class="count-value">${book.usable}</div></div>
                                              <div class="count-item"><div class="count-label">P. Damaged</div><div class="count-value">${book.partiallyDamaged}</div></div>
                                              <div class="count-item"><div class="count-label">Damaged</div><div class="count-value">${book.damaged}</div></div>
                                              <div class="count-item"><div class="count-label">Lost</div><div class="count-value">${book.lost}</div></div>
                                              <div class="count-item"><div class="count-label">Condemnable</div><div class="count-value">${book.condemnable}</div></div>
                                              <div class="total-box">
                                                <div class="count-label">Total Copies</div>
                                                <div class="count-value" style="color: #2563eb;">${book.total}</div>
                                              </div>
                                            </div>

                                            <div class="divider"></div>

                                            <div class="section-title">MODE OF ACQUISITION</div>
                                            <div class="remarks-box">
                                              ${book.acquisitionMode || 'Not specified.'}
                                            </div>

                                            <div class="footer">
                                              Generated by ${book.addedBy || 'System'} on ${new Date().toLocaleString()}
                                            </div>
                                            <script>window.print();</script>
                                          </body>
                                        </html>
                                      `);
                                      printWindow.document.close();
                                    }
                                  }} 
                                  className="p-1.5 text-text-muted hover:text-primary transition-colors"
                                  title="Print"
                                >
                                  <Printer className="w-4 h-4" />
                                </button>
                              </div>
                            </td>
                          </motion.tr>
                        ))}
                      </AnimatePresence>
                    </tbody>
                  </table>
                  {filteredBooks.length === 0 && (
                    <div className="py-20 text-center">
                      <p className="text-text-muted text-sm italic">No resources found matching your search.</p>
                    </div>
                  )}
                </div>
                
                <div className="px-4 py-3 border-t border-border bg-slate-50 flex justify-between items-center text-[10px] font-bold text-text-muted uppercase tracking-widest">
                  <span>{filteredBooks.length} records</span>
                  <div className="md:hidden">
                    <CSVTools books={books} userId={user.uid} userProfile={userProfile} />
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Modals */}
      <AnimatePresence>
        {isModalOpen && (
          <BookModal 
            book={editingBook} 
            user={user}
            userProfile={userProfile}
            books={books}
            onClose={() => setIsModalOpen(false)} 
          />
        )}
      </AnimatePresence>
    </div>
  );
}

function SidebarItem({ children, active, onClick, icon }: { children: React.ReactNode, active?: boolean, onClick: () => void, icon?: React.ReactNode, key?: any }) {
  return (
    <button 
      onClick={onClick}
      className={clsx(
        "w-full flex items-center gap-3 px-3 py-2 text-xs font-bold rounded-lg transition-all",
        active ? "bg-accent text-white" : "text-slate-300 hover:bg-secondary hover:text-white"
      )}
    >
      {icon}
      {children}
    </button>
  );
}

function StatCard({ label, value }: { label: string, value: string }) {
  return (
    <div className="bg-white p-4 rounded-xl border border-border shadow-sm">
      <span className="text-[10px] font-bold text-text-muted uppercase tracking-widest block mb-1">{label}</span>
      <span className="text-2xl font-black text-primary">{value}</span>
    </div>
  );
}

import { clsx } from 'clsx';

function LoginView({ onLogin, allUsers, user, onLogout }: { onLogin: () => void, allUsers: UserProfile[], user?: User | null, onLogout?: () => void }) {
  const [isSignUp, setIsSignUp] = useState(false);

  // If user is authenticated but landed here, they need to complete their profile
  useEffect(() => {
    if (user) {
      setIsSignUp(true);
    }
  }, [user]);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [firstName, setFirstName] = useState('');
  const [surname, setSurname] = useState('');
  const [district, setDistrict] = useState('');
  const [municipality, setMunicipality] = useState('');
  const [schoolName, setSchoolName] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleAuth = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);
    try {
      if (isSignUp) {
        // Check for existing user in the same school
        const isTaken = allUsers.some(u => u.district === district && u.municipality === municipality && u.schoolName === schoolName);
        if (isTaken) {
          setError(`A user for ${schoolName} already exists. Only one user per school is allowed.`);
          setLoading(false);
          return;
        }

        let currentUid = user?.uid;
        let currentEmail = user?.email || email;

        if (!user) {
          console.log("Attempting sign up for:", email);
          const userCredential = await createUserWithEmailAndPassword(auth, email, password);
          currentUid = userCredential.user.uid;
          currentEmail = userCredential.user.email || email;
        }
        
        console.log("Creating profile for:", currentUid);
        await setDoc(doc(db, 'users', currentUid!), {
          uid: currentUid,
          email: currentEmail,
          firstName,
          surname,
          district,
          municipality,
          schoolName,
          role: 'user',
          createdAt: new Date().toISOString()
        });
        console.log("Profile created successfully");
      } else {
        console.log("Attempting sign in for:", email);
        await signInWithEmailAndPassword(auth, email, password);
        console.log("Sign in successful");
      }
    } catch (err: any) {
      console.error("Auth error details:", err);
      if (err.code === 'auth/network-request-failed') {
        setError("Network error. Please check your internet connection or try again later.");
      } else if (err.code === 'auth/email-already-in-use') {
        setError("This email is already registered. Please sign in instead or use a different email.");
      } else if (err.code === 'auth/weak-password') {
        setError("Password should be at least 6 characters.");
      } else if (err.code === 'auth/operation-not-allowed') {
        setError("Email/Password sign-in is disabled. Please enable it in the Firebase Console (Authentication > Sign-in method).");
      } else if (err.code === 'auth/invalid-email') {
        setError("Please enter a valid email address.");
      } else if (err.code === 'auth/user-not-found' || err.code === 'auth/wrong-password' || err.code === 'auth/invalid-credential') {
        setError("Invalid email or password. Please try again.");
      } else {
        setError(err.message || "An unexpected error occurred. Please try again.");
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-bg px-4 py-12 overflow-y-auto">
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="max-w-md w-full bg-white p-8 rounded-2xl shadow-xl border border-border"
      >
        <div className="text-center mb-8">
          <div className="bg-primary w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-4 shadow-lg overflow-hidden p-1 border-2 border-white">
            <img 
              src="https://www.image2url.com/r2/default/images/1776324501949-c6254464-7439-4777-ad8a-f41d1244dba7.jpg" 
              alt="Logo" 
              className="w-full h-full object-cover rounded-full"
              referrerPolicy="no-referrer"
              onError={(e) => {
                (e.target as HTMLImageElement).src = 'https://picsum.photos/seed/education/100/100';
              }}
            />
          </div>
          <h1 className="text-2xl font-black text-primary mb-1 tracking-tight uppercase">Inventory of Learning Resource</h1>
          <p className="text-text-muted text-xs font-bold uppercase tracking-widest">
            {user ? 'Complete Your Profile' : (isSignUp ? 'Create Account' : 'Secure Access')}
          </p>
        </div>

        <form onSubmit={handleAuth} className="space-y-4">
          {user && (
            <div className="bg-blue-50 border border-blue-100 p-3 rounded-lg mb-4 text-center">
              <p className="text-[10px] text-blue-800 font-bold uppercase mb-1">Authenticated As</p>
              <p className="text-xs font-bold text-primary">{user.email}</p>
            </div>
          )}
          
          {isSignUp && (
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-[10px] font-bold text-text-muted uppercase tracking-widest mb-1">First Name</label>
                <input 
                  required
                  type="text" 
                  className="w-full px-4 py-2 bg-slate-50 border border-border rounded-lg text-sm outline-none focus:ring-2 focus:ring-accent"
                  value={firstName}
                  onChange={e => setFirstName(e.target.value)}
                />
              </div>
              <div>
                <label className="block text-[10px] font-bold text-text-muted uppercase tracking-widest mb-1">Surname</label>
                <input 
                  required
                  type="text" 
                  className="w-full px-4 py-2 bg-slate-50 border border-border rounded-lg text-sm outline-none focus:ring-2 focus:ring-accent"
                  value={surname}
                  onChange={e => setSurname(e.target.value)}
                />
              </div>
            </div>
          )}

          {!user && (
            <>
              <div>
                <label className="block text-[10px] font-bold text-text-muted uppercase tracking-widest mb-1">Email Address</label>
                <input 
                  required
                  type="email" 
                  className="w-full px-4 py-2 bg-slate-50 border border-border rounded-lg text-sm outline-none focus:ring-2 focus:ring-accent"
                  value={email}
                  onChange={e => setEmail(e.target.value)}
                />
              </div>

              <div>
                <label className="block text-[10px] font-bold text-text-muted uppercase tracking-widest mb-1">Password</label>
                <input 
                  required
                  type="password" 
                  className="w-full px-4 py-2 bg-slate-50 border border-border rounded-lg text-sm outline-none focus:ring-2 focus:ring-accent"
                  value={password}
                  onChange={e => setPassword(e.target.value)}
                />
              </div>
            </>
          )}

          {isSignUp && (
            <>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-[10px] font-bold text-text-muted uppercase tracking-widest mb-1">District</label>
                  <select 
                    className={clsx(
                      "w-full px-4 py-2 bg-slate-50 border border-border rounded-lg text-sm outline-none focus:ring-2 focus:ring-accent transition-opacity",
                      !district ? "opacity-20" : "opacity-100"
                    )}
                    value={district}
                    onChange={e => {
                      const d = e.target.value;
                      const m = DISTRICT_MAPPING[d][0];
                      setDistrict(d);
                      setMunicipality(m);
                      setSchoolName(SCHOOL_MAPPING[m]?.[0] || '');
                    }}
                  >
                    <option value="" disabled hidden>--click to select--</option>
                    {DISTRICTS.map(d => <option key={d} value={d}>{d}</option>)}
                  </select>
                </div>
                <div>
                  <label className="block text-[10px] font-bold text-text-muted uppercase tracking-widest mb-1">Municipality</label>
                  <select 
                    className={clsx(
                      "w-full px-4 py-2 bg-slate-50 border border-border rounded-lg text-sm outline-none focus:ring-2 focus:ring-accent transition-opacity",
                      !municipality ? "opacity-20" : "opacity-100"
                    )}
                    value={municipality}
                    onChange={e => {
                      const m = e.target.value;
                      setMunicipality(m);
                      setSchoolName(SCHOOL_MAPPING[m]?.[0] || '');
                    }}
                  >
                    <option value="" disabled hidden>--click to select--</option>
                    {district && DISTRICT_MAPPING[district]?.map(m => <option key={m} value={m}>{m}</option>)}
                  </select>
                </div>
              </div>
              <div className="mt-4">
                <label className="block text-[10px] font-bold text-text-muted uppercase tracking-widest mb-1">School Name</label>
                {municipality && SCHOOL_MAPPING[municipality] ? (
                  <select 
                    required
                    className={clsx(
                      "w-full px-4 py-2 bg-slate-50 border border-border rounded-lg text-sm outline-none focus:ring-2 focus:ring-accent transition-opacity",
                      !schoolName ? "opacity-20" : "opacity-100"
                    )}
                    value={schoolName}
                    onChange={e => setSchoolName(e.target.value)}
                  >
                    <option value="" disabled hidden>--click to select--</option>
                    {!schoolName && <option value="">Select School</option>}
                    {SCHOOL_MAPPING[municipality].map(s => <option key={s} value={s}>{s}</option>)}
                  </select>
                ) : (
                  <input 
                    required
                    type="text" 
                    placeholder={municipality ? "Enter school name" : "Select municipality first"}
                    disabled={!municipality}
                    className="w-full px-4 py-2 bg-slate-50 border border-border rounded-lg text-sm outline-none focus:ring-2 focus:ring-accent disabled:opacity-50"
                    value={schoolName}
                    onChange={e => setSchoolName(e.target.value)}
                  />
                )}
              </div>
            </>
          )}

          {error && <p className="text-red-500 text-[10px] font-bold uppercase text-center">{error}</p>}

          <button 
            disabled={loading}
            type="submit"
            className="w-full bg-primary hover:bg-blue-800 text-white font-bold py-3 rounded-xl transition-all shadow-md disabled:opacity-50"
          >
            {loading ? 'Processing...' : (user ? 'Create Profile' : (isSignUp ? 'Sign Up' : 'Sign In'))}
          </button>
        </form>

        {!user ? (
          <>
            <div className="mt-6 text-center">
              <button 
                onClick={() => setIsSignUp(!isSignUp)}
                className="text-accent text-xs font-bold hover:underline"
              >
                {isSignUp ? 'Already have an account? Sign In' : "Don't have an account? Sign Up"}
              </button>
            </div>

            <div className="mt-8 pt-6 border-t border-border">
              <button 
                onClick={onLogin}
                className="w-full flex items-center justify-center gap-3 bg-white border border-border hover:bg-slate-50 text-text-main font-bold py-2.5 px-4 rounded-xl transition-all shadow-sm text-xs"
              >
                <img src="https://www.google.com/favicon.ico" alt="" className="w-4 h-4" />
                Continue with Google
              </button>
            </div>
          </>
        ) : (
          <div className="mt-6 pt-6 border-t border-border text-center">
            <button 
              onClick={onLogout}
              className="text-text-muted text-xs font-bold hover:text-red-500 flex items-center justify-center gap-2 mx-auto"
            >
              <LogOut className="w-4 h-4" />
              Sign Out & Cancel
            </button>
          </div>
        )}
      </motion.div>
    </div>
  );
}

function BookModal({ book, user, userProfile, books, onClose }: { book: Book | null, user: User, userProfile: UserProfile | null, books: Book[], onClose: () => void }) {
  const userId = user.uid;
  const initialDistrict = book?.district && DISTRICTS.includes(book.district) ? book.district : '';
  const initialMunicipality = book?.municipality && DISTRICT_MAPPING[initialDistrict]?.includes(book.municipality) 
    ? book.municipality 
    : (book ? (DISTRICT_MAPPING[initialDistrict]?.[0] || '') : '');

  const [formData, setFormData] = useState<Omit<Book, 'id' | 'userId'>>({
    title: book?.title || '',
    type: book?.type || '',
    gradeLevel: book?.gradeLevel || '',
    grade: book?.grade || '',
    subject: Array.isArray(book?.subject) ? book.subject[0] || '' : (book?.subject || ''),
    author: book?.author || '',
    isbn: book?.isbn || '',
    publisher: book?.publisher || '',
    copyrightYear: book?.copyrightYear || '',
    volume: book?.volume || '',
    schoolName: book?.schoolName || '',
    district: initialDistrict,
    municipality: initialMunicipality,
    dateAcquired: book?.dateAcquired || format(new Date(), 'yyyy-MM-dd'),
    usable: book?.usable || 0,
    partiallyDamaged: book?.partiallyDamaged || 0,
    damaged: book?.damaged || 0,
    lost: book?.lost || 0,
    condemnable: book?.condemnable || 0,
    total: book?.total || 0,
    acquisitionMode: book?.acquisitionMode || '',
    utilizationMode: book?.utilizationMode || '',
    impactOnLearners: book?.impactOnLearners || '',
  });

  // Calculate total automatically
  useEffect(() => {
    const total = formData.usable + formData.partiallyDamaged + formData.damaged + formData.lost + formData.condemnable;
    setFormData(prev => ({ ...prev, total }));
  }, [formData.usable, formData.partiallyDamaged, formData.damaged, formData.lost, formData.condemnable]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    // Check for duplicate title (case-insensitive)
    const isDuplicate = books.some(b => 
      b.title.toLowerCase().trim() === formData.title.toLowerCase().trim() && 
      b.id !== book?.id
    );

    if (isDuplicate) {
      alert(`A book with the title "${formData.title}" already exists in the inventory.`);
      return;
    }

    try {
      const dataToSave = { 
        ...formData, 
        userId,
        addedBy: userProfile ? `${userProfile.firstName} ${userProfile.surname}` : (user.displayName || user.email || 'Unknown')
      };
      if (book?.id) {
        try {
          await updateDoc(doc(db, 'books', book.id), dataToSave);
          alert('Resource updated successfully!');
          onClose();
        } catch (error) {
          handleFirestoreError(error, OperationType.UPDATE, `books/${book.id}`);
          alert('Failed to update resource. Please try again.');
        }
      } else {
        try {
          await addDoc(collection(db, 'books'), dataToSave);
          alert('Resource added successfully!');
          onClose();
        } catch (error) {
          handleFirestoreError(error, OperationType.CREATE, 'books');
          alert('Failed to add resource. Please try again.');
        }
      }
    } catch (error) {
      console.error("Save error:", error);
      alert('An unexpected error occurred. Please try again.');
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-primary/40 backdrop-blur-sm overflow-y-auto">
      <motion.div 
        initial={{ opacity: 0, scale: 0.9, y: 20 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        className="bg-white w-full max-w-4xl rounded-2xl shadow-2xl overflow-hidden border border-border my-8"
      >
        <div className="px-6 py-5 border-b border-border flex items-center justify-between bg-slate-50">
          <div>
            <h3 className="text-lg font-black text-primary tracking-tight">{book ? 'Edit Resource' : 'New Resource'}</h3>
            {book && <p className="text-[10px] font-bold text-text-muted uppercase tracking-widest mt-0.5 truncate max-w-md">{book.title}</p>}
          </div>
          <button onClick={onClose} className="p-2 hover:bg-slate-200 rounded-full transition-colors">
            <X className="w-5 h-5 text-text-muted" />
          </button>
        </div>
        
        <form onSubmit={handleSubmit} className="p-8 space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {/* Basic Info */}
            <div className="space-y-4">
              <h4 className="text-xs font-black text-accent uppercase tracking-widest border-b border-slate-100 pb-2">Basic Information</h4>
              <div>
                <label className="block text-[10px] font-bold text-text-muted uppercase tracking-widest mb-1.5">Book Title</label>
                <input 
                  required
                  type="text" 
                  className="w-full px-4 py-2.5 bg-white border border-border rounded-lg focus:ring-2 focus:ring-accent outline-none transition-all text-sm"
                  value={formData.title}
                  onChange={e => setFormData({ ...formData, title: e.target.value })}
                />
              </div>
              <div>
                <label className="block text-[10px] font-bold text-text-muted uppercase tracking-widest mb-1.5">Type of Book</label>
                <select 
                  className={clsx(
                    "w-full px-4 py-2.5 bg-white border border-border rounded-lg focus:ring-2 focus:ring-accent outline-none text-sm transition-opacity",
                    !formData.type ? "opacity-20" : "opacity-100"
                  )}
                  value={formData.type}
                  onChange={e => setFormData({ ...formData, type: e.target.value })}
                >
                  <option value="" disabled hidden>--click to select--</option>
                  {BOOK_TYPES.map(t => <option key={t} value={t}>{t}</option>)}
                </select>
              </div>
              <div>
                <label className="block text-[10px] font-bold text-text-muted uppercase tracking-widest mb-1.5">Grade Level</label>
                <select 
                  className={clsx(
                    "w-full px-4 py-2.5 bg-white border border-border rounded-lg focus:ring-2 focus:ring-accent outline-none text-sm transition-opacity",
                    !formData.gradeLevel ? "opacity-20" : "opacity-100"
                  )}
                  value={formData.gradeLevel}
                  onChange={e => {
                    const level = e.target.value;
                    setFormData({ 
                      ...formData, 
                      gradeLevel: level, 
                      grade: GRADE_LEVEL_MAPPING[level]?.[0] || '',
                      subject: SUBJECT_MAPPING[level]?.[0] || ''
                    });
                  }}
                >
                  <option value="" disabled hidden>--click to select--</option>
                  {GRADE_LEVELS.map(g => <option key={g} value={g}>{g}</option>)}
                </select>
              </div>
              <div>
                <label className="block text-[10px] font-bold text-text-muted uppercase tracking-widest mb-1.5">Specific Grade</label>
                <select 
                  className={clsx(
                    "w-full px-4 py-2.5 bg-white border border-border rounded-lg focus:ring-2 focus:ring-accent outline-none text-sm transition-opacity",
                    !formData.grade ? "opacity-20" : "opacity-100"
                  )}
                  value={formData.grade}
                  onChange={e => setFormData({ ...formData, grade: e.target.value })}
                >
                  <option value="" disabled hidden>--click to select--</option>
                  {GRADE_LEVEL_MAPPING[formData.gradeLevel]?.map(g => <option key={g} value={g}>{g}</option>)}
                </select>
              </div>
              <div>
                <label className="block text-[10px] font-bold text-text-muted uppercase tracking-widest mb-1.5">Subject</label>
                <select 
                  className={clsx(
                    "w-full px-4 py-2.5 bg-white border border-border rounded-lg focus:ring-2 focus:ring-accent outline-none text-sm transition-opacity",
                    !formData.subject ? "opacity-20" : "opacity-100"
                  )}
                  value={formData.subject}
                  onChange={e => setFormData({ ...formData, subject: e.target.value })}
                >
                  <option value="" disabled hidden>--click to select--</option>
                  {(SUBJECT_MAPPING[formData.gradeLevel] || SUBJECTS_LIST).map(s => (
                    <option key={s} value={s}>{s}</option>
                  ))}
                </select>
              </div>
            </div>

            {/* Publication Info */}
            <div className="space-y-4">
              <h4 className="text-xs font-black text-accent uppercase tracking-widest border-b border-slate-100 pb-2">Publication & Delivery</h4>
              <div>
                <label className="block text-[10px] font-bold text-text-muted uppercase tracking-widest mb-1.5">Author/s</label>
                <input 
                  type="text" 
                  className="w-full px-4 py-2.5 bg-white border border-border rounded-lg focus:ring-2 focus:ring-accent outline-none text-sm"
                  value={formData.author}
                  onChange={e => setFormData({ ...formData, author: e.target.value })}
                />
              </div>
              <div>
                <label className="block text-[10px] font-bold text-text-muted uppercase tracking-widest mb-1.5">ISBN Number</label>
                <input 
                  type="text" 
                  className="w-full px-4 py-2.5 bg-white border border-border rounded-lg focus:ring-2 focus:ring-accent outline-none text-sm"
                  value={formData.isbn}
                  onChange={e => setFormData({ ...formData, isbn: e.target.value })}
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-[10px] font-bold text-text-muted uppercase tracking-widest mb-1.5">Publisher</label>
                  <input 
                    type="text" 
                    className="w-full px-4 py-2.5 bg-white border border-border rounded-lg focus:ring-2 focus:ring-accent outline-none text-sm"
                    value={formData.publisher}
                    onChange={e => setFormData({ ...formData, publisher: e.target.value })}
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-bold text-text-muted uppercase tracking-widest mb-1.5">Copyright Year</label>
                  <input 
                    type="text" 
                    className="w-full px-4 py-2.5 bg-white border border-border rounded-lg focus:ring-2 focus:ring-accent outline-none text-sm"
                    value={formData.copyrightYear}
                    onChange={e => setFormData({ ...formData, copyrightYear: e.target.value })}
                  />
                </div>
              </div>
              <div>
                <label className="block text-[10px] font-bold text-text-muted uppercase tracking-widest mb-1.5">Volume</label>
                <input 
                  type="text" 
                  className="w-full px-4 py-2.5 bg-white border border-border rounded-lg focus:ring-2 focus:ring-accent outline-none text-sm"
                  value={formData.volume}
                  onChange={e => setFormData({ ...formData, volume: e.target.value })}
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-[10px] font-bold text-text-muted uppercase tracking-widest mb-1.5">District</label>
                  <select 
                    className={clsx(
                      "w-full px-4 py-2.5 bg-white border border-border rounded-lg focus:ring-2 focus:ring-accent outline-none text-sm transition-opacity",
                      !formData.district ? "opacity-20" : "opacity-100"
                    )}
                    value={formData.district}
                    onChange={e => {
                      const dist = e.target.value;
                      const newMuni = DISTRICT_MAPPING[dist]?.[0] || '';
                      setFormData({ 
                        ...formData, 
                        district: dist,
                        municipality: newMuni,
                        schoolName: SCHOOL_MAPPING[newMuni]?.[0] || formData.schoolName
                      });
                    }}
                  >
                    <option value="" disabled hidden>--click to select--</option>
                    {DISTRICTS.map(d => <option key={d} value={d}>{d}</option>)}
                  </select>
                </div>
                <div>
                  <label className="block text-[10px] font-bold text-text-muted uppercase tracking-widest mb-1.5">Municipality</label>
                  <select 
                    className={clsx(
                      "w-full px-4 py-2.5 bg-white border border-border rounded-lg focus:ring-2 focus:ring-accent outline-none text-sm transition-opacity",
                      !formData.municipality ? "opacity-20" : "opacity-100"
                    )}
                    value={formData.municipality}
                    onChange={e => {
                      const muni = e.target.value;
                      setFormData({ 
                        ...formData, 
                        municipality: muni,
                        schoolName: SCHOOL_MAPPING[muni]?.[0] || formData.schoolName
                      });
                    }}
                  >
                    <option value="" disabled hidden>--click to select--</option>
                    {DISTRICT_MAPPING[formData.district]?.map(m => <option key={m} value={m}>{m}</option>)}
                  </select>
                </div>
              </div>
              <div>
                <label className="block text-[10px] font-bold text-text-muted uppercase tracking-widest mb-1.5">School Name</label>
                {SCHOOL_MAPPING[formData.municipality] ? (
                  <select 
                    className={clsx(
                      "w-full px-4 py-2.5 bg-white border border-border rounded-lg focus:ring-2 focus:ring-accent outline-none text-sm transition-opacity",
                      !formData.schoolName ? "opacity-20" : "opacity-100"
                    )}
                    value={formData.schoolName}
                    onChange={e => setFormData({ ...formData, schoolName: e.target.value })}
                  >
                    <option value="" disabled hidden>--click to select--</option>
                    {!formData.schoolName && <option value="">Select School</option>}
                    {SCHOOL_MAPPING[formData.municipality].map(s => <option key={s} value={s}>{s}</option>)}
                  </select>
                ) : (
                  <input 
                    type="text" 
                    placeholder="Enter school name"
                    className="w-full px-4 py-2.5 bg-white border border-border rounded-lg focus:ring-2 focus:ring-accent outline-none text-sm"
                    value={formData.schoolName}
                    onChange={e => setFormData({ ...formData, schoolName: e.target.value })}
                  />
                )}
              </div>
              <div>
                <label className="block text-[10px] font-bold text-text-muted uppercase tracking-widest mb-1.5">Date Acquired</label>
                <input 
                  type="date" 
                  className="w-full px-4 py-2.5 bg-white border border-border rounded-lg focus:ring-2 focus:ring-accent outline-none text-sm"
                  value={formData.dateAcquired}
                  onChange={e => setFormData({ ...formData, dateAcquired: e.target.value })}
                />
              </div>
            </div>

            {/* Inventory Counts */}
            <div className="space-y-4">
              <h4 className="text-xs font-black text-accent uppercase tracking-widest border-b border-slate-100 pb-2">Inventory Counts</h4>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-[10px] font-bold text-text-muted uppercase tracking-widest mb-1.5">Usable</label>
                  <input 
                    type="number" 
                    className="w-full px-4 py-2.5 bg-white border border-border rounded-lg focus:ring-2 focus:ring-accent outline-none text-sm"
                    value={formData.usable}
                    onChange={e => setFormData({ ...formData, usable: parseInt(e.target.value) || 0 })}
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-bold text-text-muted uppercase tracking-widest mb-1.5">Partially Damaged</label>
                  <input 
                    type="number" 
                    className="w-full px-4 py-2.5 bg-white border border-border rounded-lg focus:ring-2 focus:ring-accent outline-none text-sm"
                    value={formData.partiallyDamaged}
                    onChange={e => setFormData({ ...formData, partiallyDamaged: parseInt(e.target.value) || 0 })}
                  />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-[10px] font-bold text-text-muted uppercase tracking-widest mb-1.5">Damaged</label>
                  <input 
                    type="number" 
                    className="w-full px-4 py-2.5 bg-white border border-border rounded-lg focus:ring-2 focus:ring-accent outline-none text-sm"
                    value={formData.damaged}
                    onChange={e => setFormData({ ...formData, damaged: parseInt(e.target.value) || 0 })}
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-bold text-text-muted uppercase tracking-widest mb-1.5">Lost</label>
                  <input 
                    type="number" 
                    className="w-full px-4 py-2.5 bg-white border border-border rounded-lg focus:ring-2 focus:ring-accent outline-none text-sm"
                    value={formData.lost}
                    onChange={e => setFormData({ ...formData, lost: parseInt(e.target.value) || 0 })}
                  />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-[10px] font-bold text-text-muted uppercase tracking-widest mb-1.5">Condemnable</label>
                  <input 
                    type="number" 
                    className="w-full px-4 py-2.5 bg-white border border-border rounded-lg focus:ring-2 focus:ring-accent outline-none text-sm"
                    value={formData.condemnable}
                    onChange={e => setFormData({ ...formData, condemnable: parseInt(e.target.value) || 0 })}
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-bold text-text-muted uppercase tracking-widest mb-1.5">TOTAL</label>
                  <input 
                    readOnly
                    type="number" 
                    className="w-full px-4 py-2.5 bg-slate-50 border border-border rounded-lg text-sm font-black text-primary"
                    value={formData.total}
                  />
                </div>
              </div>
              <div>
                <label className="block text-[10px] font-bold text-text-muted uppercase tracking-widest mb-1.5">Mode of Acquisition</label>
                <select 
                  className={clsx(
                    "w-full px-4 py-2.5 bg-white border border-border rounded-lg focus:ring-2 focus:ring-accent outline-none text-sm transition-opacity",
                    !formData.acquisitionMode ? "opacity-20" : "opacity-100"
                  )}
                  value={formData.acquisitionMode}
                  onChange={e => setFormData({ ...formData, acquisitionMode: e.target.value })}
                >
                  <option value="" disabled hidden>--click to select--</option>
                  {ACQUISITION_MODES.map(mode => <option key={mode} value={mode}>{mode}</option>)}
                </select>
              </div>
              <div>
                <label className="block text-[10px] font-bold text-text-muted uppercase tracking-widest mb-1.5">Mode of Utilization</label>
                <select 
                  className={clsx(
                    "w-full px-4 py-2.5 bg-white border border-border rounded-lg focus:ring-2 focus:ring-accent outline-none text-sm transition-opacity",
                    !formData.utilizationMode ? "opacity-20" : "opacity-100"
                  )}
                  value={formData.utilizationMode}
                  onChange={e => setFormData({ ...formData, utilizationMode: e.target.value })}
                >
                  <option value="" disabled hidden>--click to select--</option>
                  {UTILIZATION_MODES.map(mode => <option key={mode} value={mode}>{mode}</option>)}
                </select>
              </div>
              <div>
                <label className="block text-[10px] font-bold text-text-muted uppercase tracking-widest mb-1.5">Impact on performance of Learners</label>
                <select 
                  className={clsx(
                    "w-full px-4 py-2.5 bg-white border border-border rounded-lg focus:ring-2 focus:ring-accent outline-none text-sm transition-opacity",
                    !formData.impactOnLearners ? "opacity-20" : "opacity-100"
                  )}
                  value={formData.impactOnLearners}
                  onChange={e => setFormData({ ...formData, impactOnLearners: e.target.value })}
                >
                  <option value="" disabled hidden>--click to select--</option>
                  {IMPACT_OPTIONS.map(option => <option key={option} value={option}>{option}</option>)}
                </select>
              </div>
            </div>
          </div>

          <div className="pt-6 flex gap-4 border-t border-slate-100">
            <button 
              type="button"
              onClick={onClose}
              className="flex-1 px-4 py-3 border border-border text-text-muted font-bold rounded-lg hover:bg-slate-50 transition-colors text-sm"
            >
              Cancel
            </button>
            <button 
              type="submit"
              className="flex-1 px-4 py-3 bg-accent text-white font-bold rounded-lg hover:bg-blue-700 transition-colors shadow-lg shadow-blue-100 text-sm"
            >
              {book ? 'Update Resource' : 'Save Resource'}
            </button>
          </div>
        </form>
      </motion.div>
    </div>
  );
}

function CSVTools({ books, userId, userProfile }: { books: Book[], userId: string, userProfile: UserProfile | null }) {
  const handleExport = () => {
    const csv = Papa.unparse(books.map(({ id, userId, ...rest }) => ({
      ...rest,
      subject: rest.subject
    })));
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    const url = URL.createObjectURL(blob);
    link.setAttribute('href', url);
    link.setAttribute('download', `lr_inventory_${format(new Date(), 'yyyy-MM-dd')}.csv`);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="flex gap-2">
      <button 
        onClick={handleExport}
        className="flex items-center gap-2 px-4 py-2.5 bg-white border border-border text-text-muted rounded-lg hover:bg-slate-50 transition-colors text-sm font-bold"
      >
        <FileDown className="w-4 h-4" />
        Export
      </button>
    </div>
  );
}

function UsersView({ users, currentUserProfile, onClose }: { users: UserProfile[], currentUserProfile: UserProfile | null, onClose: () => void }) {
  const isAdmin = currentUserProfile?.role === 'admin';

  const handleDeleteUser = async (userId: string) => {
    try {
      await deleteDoc(doc(db, 'users', userId));
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, `users/${userId}`);
    }
  };

  const handleToggleRole = async (u: UserProfile) => {
    const newRole = u.role === 'admin' ? 'user' : 'admin';
    try {
      await updateDoc(doc(db, 'users', u.uid), { role: newRole });
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, `users/${u.uid}`);
    }
  };

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-white border border-border rounded-xl shadow-sm overflow-hidden"
    >
      <div className="px-6 py-4 border-b border-border flex items-center justify-between bg-slate-50">
        <h2 className="text-lg font-black text-primary tracking-tight uppercase">System Users</h2>
        <button onClick={onClose} className="p-2 hover:bg-slate-200 rounded-full transition-colors">
          <X className="w-5 h-5 text-text-muted" />
        </button>
      </div>
      <div className="overflow-x-auto">
        <table className="w-full text-left border-collapse">
          <thead>
            <tr className="bg-slate-50 border-b-2 border-border">
              <th className="px-6 py-4 text-[10px] font-bold text-secondary uppercase tracking-wider">Name of User</th>
              <th className="px-6 py-4 text-[10px] font-bold text-secondary uppercase tracking-wider">Email</th>
              <th className="px-6 py-4 text-[10px] font-bold text-secondary uppercase tracking-wider">District</th>
              <th className="px-6 py-4 text-[10px] font-bold text-secondary uppercase tracking-wider">Municipality</th>
              {isAdmin && <th className="px-6 py-4 text-[10px] font-bold text-secondary uppercase tracking-wider text-center">Actions</th>}
            </tr>
          </thead>
          <tbody className="divide-y divide-border">
            {users.map((u) => (
              <tr key={u.uid} className="hover:bg-slate-50 transition-colors">
                <td className="px-6 py-4">
                  <span className="text-xs font-bold text-text-main">
                    {u.firstName ? `${u.firstName} ${u.surname}` : 'N/A'}
                  </span>
                </td>
                <td className="px-6 py-4 text-xs text-text-muted">{u.email}</td>
                <td className="px-6 py-4 text-xs text-text-muted font-medium">{u.district || 'N/A'}</td>
                <td className="px-6 py-4 text-xs text-text-muted">{u.municipality || 'N/A'}</td>
                {isAdmin && (
                  <td className="px-6 py-4 text-center">
                    <div className="flex items-center justify-center gap-2">
                      {u.uid !== currentUserProfile?.uid && (
                        <>
                          <button 
                            onClick={() => handleToggleRole(u)}
                            className={clsx(
                              "px-2 py-1 text-[10px] font-bold rounded uppercase transition-colors",
                              u.role === 'admin' ? "bg-accent text-white" : "bg-slate-100 text-text-muted hover:bg-slate-200"
                            )}
                            title={u.role === 'admin' ? "Revoke Admin" : "Make Admin"}
                          >
                            {u.role === 'admin' ? 'Admin' : 'User'}
                          </button>
                          <button 
                            onClick={() => handleDeleteUser(u.uid)}
                            className="p-1.5 text-text-muted hover:text-red-500 transition-colors"
                            title="Delete User"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </>
                      )}
                      {u.uid === currentUserProfile?.uid && (
                        <span className="px-2 py-1 text-[10px] font-bold rounded uppercase bg-accent text-white">You</span>
                      )}
                    </div>
                  </td>
                )}
              </tr>
            ))}
          </tbody>
        </table>
        {users.length === 0 && (
          <div className="py-20 text-center">
            <p className="text-text-muted text-sm italic">No users found.</p>
          </div>
        )}
      </div>
    </motion.div>
  );
}

function ReportsView({ books, onClose }: { books: Book[], onClose: () => void }) {
  const [filter, setFilter] = useState({
    dateRange: '',
    district: '',
    municipality: '',
    subject: '',
    school: ''
  });

  const filteredData = useMemo(() => {
    return books.filter(book => {
      const dateMatch = filter.dateRange === 'all' || filter.dateRange === '' || (() => {
        const bookDate = parseISO(book.dateAcquired);
        const now = new Date();
        if (filter.dateRange === 'last-month') {
          return isWithinInterval(bookDate, { start: startOfMonth(new Date(now.getFullYear(), now.getMonth() - 1)), end: endOfMonth(new Date(now.getFullYear(), now.getMonth() - 1)) });
        }
        if (filter.dateRange === 'last-quarter') {
          return isWithinInterval(bookDate, { start: startOfQuarter(new Date(now.getFullYear(), now.getMonth() - 3)), end: endOfQuarter(new Date(now.getFullYear(), now.getMonth() - 1)) });
        }
        return true;
      })();

      const districtMatch = filter.district === 'all' || filter.district === '' || book.district === filter.district;
      const municipalityMatch = filter.municipality === 'all' || filter.municipality === '' || book.municipality === filter.municipality;
      const schoolMatch = filter.school === 'all' || filter.school === '' || book.schoolName === filter.school;
      const subjectMatch = filter.subject === 'all' || filter.subject === '' || book.subject === filter.subject;

      return dateMatch && districtMatch && municipalityMatch && schoolMatch && subjectMatch;
    });
  }, [books, filter]);

  const totalCopies = filteredData.reduce((sum, b) => sum + (b.total || (b as any).copies || 0), 0);

  const statsByGroup = useMemo(() => {
    const stats: Record<string, number> = {};
    filteredData.forEach(b => {
      const val = b.total || (b as any).copies || 0;
      let groupKey = b.district;
      if (filter.district !== 'all' && filter.district !== '') groupKey = b.municipality;
      if (filter.municipality !== 'all' && filter.municipality !== '') groupKey = b.schoolName;
      
      stats[groupKey] = (stats[groupKey] || 0) + val;
    });
    return Object.entries(stats).sort((a, b) => b[1] - a[1]);
  }, [filteredData, filter.district, filter.municipality]);

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="space-y-8 pb-10"
    >
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-black text-primary tracking-tight">Distribution Reports</h2>
          <p className="text-text-muted mt-1 text-sm">Analyze book distribution metrics and summaries.</p>
        </div>
        <button onClick={onClose} className="p-2 hover:bg-slate-200 rounded-full transition-colors">
          <X className="w-6 h-6 text-text-muted" />
        </button>
      </div>

      <div className="bg-white p-8 rounded-2xl border border-border shadow-sm grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-8">
        <div>
          <label className="block text-[10px] font-bold text-text-muted uppercase tracking-widest mb-2.5">Date Range</label>
          <select 
            className={clsx(
              "w-full px-4 py-2.5 bg-slate-50 border border-border rounded-lg outline-none focus:ring-2 focus:ring-accent text-sm transition-opacity",
              !filter.dateRange ? "opacity-20" : "opacity-100"
            )}
            value={filter.dateRange}
            onChange={e => setFilter({ ...filter, dateRange: e.target.value })}
          >
            <option value="" disabled hidden>--click to select--</option>
            <option value="all">All Time</option>
            <option value="last-month">Last Month</option>
            <option value="last-quarter">Last Quarter</option>
          </select>
        </div>
        <div>
          <label className="block text-[10px] font-bold text-text-muted uppercase tracking-widest mb-2.5">District</label>
          <select 
            className={clsx(
              "w-full px-4 py-2.5 bg-slate-50 border border-border rounded-lg outline-none focus:ring-2 focus:ring-accent text-sm transition-opacity",
              !filter.district ? "opacity-20" : "opacity-100"
            )}
            value={filter.district}
            onChange={e => setFilter({ ...filter, district: e.target.value, municipality: '', school: '' })}
          >
            <option value="" disabled hidden>--click to select--</option>
            <option value="all">All Districts</option>
            {DISTRICTS.map(d => <option key={d} value={d}>{d}</option>)}
          </select>
        </div>
        <div>
          <label className="block text-[10px] font-bold text-text-muted uppercase tracking-widest mb-2.5">Municipality</label>
          <select 
            className={clsx(
              "w-full px-4 py-2.5 bg-slate-50 border border-border rounded-lg outline-none focus:ring-2 focus:ring-accent text-sm transition-opacity",
              !filter.municipality ? "opacity-20" : "opacity-100"
            )}
            value={filter.municipality}
            onChange={e => setFilter({ ...filter, municipality: e.target.value, school: '' })}
            disabled={filter.district === 'all' || filter.district === ''}
          >
            <option value="" disabled hidden>--click to select--</option>
            <option value="all">All Municipalities</option>
            {filter.district !== 'all' && filter.district !== '' && DISTRICT_MAPPING[filter.district]?.map(m => (
              <option key={m} value={m}>{m}</option>
            ))}
          </select>
        </div>
        <div>
          <label className="block text-[10px] font-bold text-text-muted uppercase tracking-widest mb-2.5">School</label>
          <select 
            className={clsx(
              "w-full px-4 py-2.5 bg-slate-50 border border-border rounded-lg outline-none focus:ring-2 focus:ring-accent text-sm transition-opacity",
              !filter.school ? "opacity-20" : "opacity-100"
            )}
            value={filter.school}
            onChange={e => setFilter({ ...filter, school: e.target.value })}
            disabled={filter.municipality === 'all' || filter.municipality === '' || !SCHOOL_MAPPING[filter.municipality]}
          >
            <option value="" disabled hidden>--click to select--</option>
            <option value="all">All Schools</option>
            {filter.municipality !== 'all' && filter.municipality !== '' && SCHOOL_MAPPING[filter.municipality]?.map(s => (
              <option key={s} value={s}>{s}</option>
            ))}
          </select>
        </div>
        <div>
          <label className="block text-[10px] font-bold text-text-muted uppercase tracking-widest mb-2.5">Subject</label>
          <select 
            className={clsx(
              "w-full px-4 py-2.5 bg-slate-50 border border-border rounded-lg outline-none focus:ring-2 focus:ring-accent text-sm transition-opacity",
              !filter.subject ? "opacity-20" : "opacity-100"
            )}
            value={filter.subject}
            onChange={e => setFilter({ ...filter, subject: e.target.value })}
          >
            <option value="" disabled hidden>--click to select--</option>
            <option value="all">All Subjects</option>
            {SUBJECTS_LIST.map(s => <option key={s} value={s}>{s}</option>)}
          </select>
        </div>
        <div className="bg-primary rounded-xl p-6 text-white flex flex-col justify-center shadow-lg shadow-slate-200">
          <span className="text-[10px] font-bold uppercase tracking-widest opacity-60 mb-1">Total Distributed</span>
          <span className="text-3xl font-black">{(totalCopies || 0).toLocaleString()}</span>
        </div>
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-2 gap-8">
        <div className="bg-white p-8 rounded-2xl border border-border shadow-sm">
          <h3 className="text-lg font-black mb-8 flex items-center gap-3 text-primary tracking-tight">
            <Filter className="w-5 h-5 text-accent" />
            {filter.district === 'all' ? 'Distribution by District' : (filter.municipality === 'all' ? `Distribution in ${filter.district}` : `Distribution in ${filter.municipality}`)}
          </h3>
          <div className="space-y-6 max-h-[400px] overflow-y-auto pr-4">
            {statsByGroup?.map(([group, count]) => (
              <div key={group} className="flex items-center gap-4">
                <div className="flex-1">
                  <div className="flex justify-between text-sm mb-2">
                    <span className="font-bold text-slate-700">{group}</span>
                    <span className="text-text-muted font-bold">{(count || 0).toLocaleString()} copies</span>
                  </div>
                  <div className="h-2.5 bg-slate-100 rounded-full overflow-hidden">
                    <motion.div 
                      initial={{ width: 0 }}
                      animate={{ width: `${totalCopies > 0 ? (count / totalCopies) * 100 : 0}%` }}
                      className="h-full bg-accent"
                    />
                  </div>
                </div>
              </div>
            ))}
            {statsByGroup.length === 0 && <p className="text-text-muted text-center py-10 text-sm">No data for selected filters.</p>}
          </div>
        </div>

        <div className="bg-white p-8 rounded-2xl border border-border shadow-sm flex flex-col">
          <h3 className="text-lg font-black mb-8 flex items-center gap-3 text-primary tracking-tight">
            <Download className="w-5 h-5 text-accent" />
            Filtered Data Summary
          </h3>
          <div className="overflow-x-auto flex-1">
            <table className="w-full text-sm">
              <thead>
                <tr className="text-left border-b border-border">
                  <th className="pb-4 text-[10px] font-bold text-text-muted uppercase tracking-widest">Title</th>
                  <th className="pb-4 text-[10px] font-bold text-text-muted uppercase tracking-widest">Location</th>
                  <th className="pb-4 text-[10px] font-bold text-text-muted uppercase tracking-widest text-center">Usable</th>
                  <th className="pb-4 text-[10px] font-bold text-text-muted uppercase tracking-widest text-center">Damaged</th>
                  <th className="pb-4 text-[10px] font-bold text-text-muted uppercase tracking-widest text-right">Total</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-50">
                {filteredData.slice(0, 10).map(book => (
                  <tr key={book.id}>
                    <td className="py-4 font-bold text-text-main">{book.title}</td>
                    <td className="py-4 text-text-muted font-medium">
                      <div className="flex flex-col">
                        <span>{book.district}</span>
                        <span className="text-[10px] opacity-60">{book.municipality}</span>
                      </div>
                    </td>
                    <td className="py-4 text-center text-success font-bold">{book.usable?.toLocaleString() || 0}</td>
                    <td className="py-4 text-center text-red-500 font-bold">{(book.damaged + book.partiallyDamaged)?.toLocaleString() || 0}</td>
                    <td className="py-4 text-right font-black text-accent">{(book.total || (book as any).copies || 0).toLocaleString()}</td>
                  </tr>
                ))}
              </tbody>
            </table>
            {filteredData.length > 10 && (
              <p className="text-[10px] font-bold text-text-muted mt-6 text-center uppercase tracking-widest">Showing first 10 records. Export for full data.</p>
            )}
            {filteredData.length === 0 && <p className="text-text-muted text-center py-10 text-sm">No records found.</p>}
          </div>
        </div>
      </div>
    </motion.div>
  );
}
