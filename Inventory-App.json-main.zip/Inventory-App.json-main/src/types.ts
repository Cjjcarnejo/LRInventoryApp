export interface Book {
  id?: string;
  title: string;
  type: string;
  gradeLevel: string;
  grade: string;
  subject: string;
  author: string;
  isbn: string;
  publisher: string;
  copyrightYear: string;
  volume: string;
  schoolName: string;
  district: string;
  municipality: string;
  dateAcquired: string;
  usable: number;
  partiallyDamaged: number;
  damaged: number;
  lost: number;
  condemnable: number;
  total: number;
  acquisitionMode: string;
  utilizationMode: string;
  impactOnLearners: string;
  userId: string;
  addedBy?: string;
}

export interface UserProfile {
  uid: string;
  email: string | null;
  firstName: string;
  surname: string;
  district: string;
  municipality: string;
  schoolName?: string;
  role?: 'admin' | 'user';
  createdAt?: string;
}
